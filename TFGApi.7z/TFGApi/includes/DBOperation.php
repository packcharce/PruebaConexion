<?php


class DbOperation
{
    //Database connection link
    private $con;


    //Class constructor
    function __construct()
    {
        //Getting the DbConnect.php file
        require_once dirname(__FILE__) . '/DbConnect.php';

        //Creating a DbConnect object to connect to the database
        $db = new DbConnect();

        //Initializing our connection link of this class
        //by calling the method connect of DbConnect class
        $this->con = $db->connect();
    }

    function getErrores()
    {
        global $errores;
        return $errores;
    }

    // ------------------------------------------------------------------------------------------------------------------------------------------------
    // DATOS----------------------------------------------------------------------------------------------------------------------------------------
    // ------------------------------------------------------------------------------------------------------------------------------------------------

    /*
    * Operacion select de fijos
    * FIJOS
    */
    function cargaDatos($nombreTabla)
    {
        try {
            $stmt = $this->con->prepare("SELECT id, nombre, ingredientes, precio FROM $nombreTabla");
            if ($stmt) {
                $stmt->execute();
                $stmt->bind_result($id, $nombre, $ingrediente, $precio);
                $fijo = array();

                while ($stmt->fetch()) {
                    $pedido = array();
                    $pedido['id'] = $id;
                    $pedido['nombre'] = $nombre;
                    $pedido['ingredientes'] = $ingrediente;
                    $pedido['precio'] = $precio;

                    array_push($fijo, $pedido);
                }
                return $fijo;
            }
        } catch (Exception $e) {
            global $errores;
            $errores = array(
                "numError" => $stmt->errno,
                "descError" => $stmt->error);
            echo $e->errorMessage();
        }
    }

    // ------------------------------------------------------------------------------------------------------------------------------------------------
    // Ingredientes------------------------------------------------------------------------------------------------------------------------------------
    // ------------------------------------------------------------------------------------------------------------------------------------------------
    function cargaIngredientes()
    {
        try {
            $stmt = $this->con->prepare("select id, tipo, nombre, stock, precio from ingrediente;");
            if ($stmt) {
                $stmt->execute();
                $stmt->bind_result($id, $tipo, $nombreIngrediente, $stockIngrediente, $precio);
                $fijo = array();

                while ($stmt->fetch()) {
                    $pedido = array();
                    $pedido['id'] = $id;
                    $pedido['tipo'] = $tipo;
                    $pedido['nombre'] = $nombreIngrediente;
                    $pedido['stock'] = $stockIngrediente;
                    $pedido['precio'] = $precio;

                    array_push($fijo, $pedido);
                }
                return $fijo;
            }
        } catch (Exception $e) {
            global $errores;
            $errores = array(
                "numError" => $stmt->errno,
                "descError" => $stmt->error);
            echo $e->errorMessage();
        }
    }


    // ------------------------------------------------------------------------------------------------------------------------------------------------
    // CLIENTES----------------------------------------------------------------------------------------------------------------------------------------
    // ------------------------------------------------------------------------------------------------------------------------------------------------

    /*
    * Crear clientes
    */
    function createCliente($nombre, $apellido, $apellido2, $tlfno, $calle, $portal, $piso, $puerta, $urbanizacion, $usuario, $contrasenia, $codigoPostal)
    {
        try {
            if (!$this->con->query("CALL crea_cliente('$nombre', '$apellido','$apellido2', '$tlfno', '$calle', '$portal', '$piso', '$puerta', '$urbanizacion', '$usuario', '$contrasenia', '$codigoPostal')")) {
                //echo "Falló CALL: (" . $this->con->errno . ") " . $this->con->error;
                global $errores;
                $errores = array(
                    "numError" => $this->con->errno,
                    "descError" => $this->con->error);
                return false;
            }
            return true;
        } catch (Exception $e) {
            global $errores;
            $errores = array(
                "numError" => $this->con->errno,
                "descError" => $this->con->error);
            echo $e->errorMessage();
        }
    }

    /*
    * Operacion select de clientes
    * LOGIN
    */
    function login($usuario, $contrasenia)
    {
        try {
            $stmt = $this->con->prepare("SELECT id, nombre, apellido1, tlfno, calle, portal, piso, puerta, urbanizacion, codigoPostal FROM cliente WHERE usuario = ? AND contrasenia = SHA2(?, 384)");
            if ($stmt) {
                $stmt->bind_param("ss", $usuario, $contrasenia);
                $stmt->execute();
                /*$stmt->store_result();
                $res = $stmt->num_rows;*/
                $stmt->bind_result($id, $nombre, $apellido, $tlfno, $calle, $portal, $piso, $puerta, $urbanizacion, $codigoPostal);
                $fijo = array();

                while ($stmt->fetch()) {
                    $pedido = array();
                    $pedido['id'] = $id;
                    $pedido['nombre'] = $nombre;
                    $pedido['apellido'] = $apellido;
                    $pedido['tlfno'] = $tlfno;
                    $pedido['calle'] = $calle;
                    $pedido['portal'] = $portal;
                    $pedido['piso'] = $piso;
                    $pedido['puerta'] = $puerta;
                    $pedido['urbanizacion'] = $urbanizacion;
                    $pedido['codigoPostal'] = $codigoPostal;
                    array_push($fijo, $pedido);
                }
                return $fijo;
            }
        } catch (PDOException $e) {
            global $errores;
            $errores = array(
                "numError" => $this->con->errno,
                "descError" => $this->con->error);
            echo $e->errorMessage();
        }
    }


    /*
    * Update cliente
    *
    */
    function updateCliente($id, $nombre, $apellido, $tlfno, $calle, $portal, $piso, $puerta, $urbanizacion, $codigoPostal)
    {
        try {
            $stmt = $this->con->prepare("UPDATE cliente SET nombre = ?, apellido1 = ?, tlfno = ?, calle = ?, portal = ?, piso = ?, puerta = ?, urbanizacion = ?, codigoPostal = ? WHERE id = $id");
            if ($stmt) {
                $stmt->bind_param("sssssssss", $nombre, $apellido, $tlfno, $calle, $portal, $piso, $puerta, $urbanizacion, $codigoPostal/*, $id*/);
                if ($stmt->execute()) {
                    return true;
                }
                return false;
            }
        } catch (PDOException $e) {
            global $errores;
            $errores = array(
                "numError" => $this->con->errno,
                "message" => $this->con->error
            );
        }
    }

    // ------------------------------------------------------------------------------------------------------------------------------------------------
    // PEDIDOS-----------------------------------------------------------------------------------------------------------------------------------------
    // ------------------------------------------------------------------------------------------------------------------------------------------------

    /*
    * Crear pedido
    */
    function createPedido($refCliente, $numPedido, $extra_domicilio, $extra_local, $extra_recoger, $subtotal, $impuesto, $total, $listaPizzas, $listaLasania, $listaEnsaladas, $listaBebs, $listaPasta, $listaHamburguesas)
    {
        try {
            $refCliente = json_decode($refCliente);
            $numPedido = json_decode($numPedido);
            $extra_domicilio = json_decode($extra_domicilio);
            $extra_recoger = json_decode($extra_recoger);
            $extra_local = json_decode($extra_local);
            $subtotal = json_decode($subtotal);
            $impuesto = json_decode($impuesto);
            $total = json_decode($total);

            if (!$this->con->query("INSERT into pedido (refCliente, numPedido, extra_domicilio, extra_local, extra_recoger, subtotal, impuesto, total) values ('$refCliente', '$numPedido', '$extra_domicilio', '$extra_recoger', '$extra_local', '$subtotal', '$impuesto', '$total')")) {
                global $errores;
                $errores = array(
                    "numError" => $this->con->errno,
                    //"numError" => $total,
                    "descError" => $this->con->error);
                return false;
            }

            $lastIdPedido = $this->con->insert_id;

            //var_dump($listaPizzas);


            foreach ($listaPizzas as $pizza):
                //Dentro de la lista pizzas


                /*
                 *
                 * Insertar Pizza
                 *
                 */
                if (!$this->con->query("INSERT into pizza (nombre, precio) values ('$pizza->nombre', '$pizza->precio')")) {
                    global $errores;
                    $errores = array(
                        "numError" => $this->con->errno,
                        "descError" => $this->con->error);
                    return false;
                }


                /*
                 *
                 * Insertar pizza en lista pizzas del pedido
                 *
                 */
                $lastIdPizza = $this->con->insert_id;
                if (!$this->con->query("INSERT into listaPizzas (refPedido, refPizza) values ('$lastIdPedido', '$lastIdPizza')")) {
                    global $errores;
                    $errores = array(
                        "numError" => $this->con->errno,
                        "descError" => $this->con->error);
                    return false;
                }

                /*
                 *
                 * Insertar:
                 * Ingredientes de la pizza
                 *
                 */
                foreach ($pizza as $listaIngrediente):

                    /*
                     *
                     * Insertar ingrediente uno a uno en lista ingredientes
                     * de la pizza
                     *
                     */
                    if (is_array($listaIngrediente)) {

                        foreach ($listaIngrediente as $ingrediente):

                            if (!$this->con->query("INSERT into listaIngredientes (refPizza, refIngrediente, mitad) values ('$lastIdPizza', '$ingrediente->id', '$ingrediente->mitad')")) {
                                global $errores;
                                $errores = array(
                                    "numError" => $this->con->errno,
                                    //"numError" => $total,
                                    "descError" => $this->con->error);
                                return false;
                            }

                            //echo "\n---------------------------- Fin de Ingrediente -----------------------\n";
                        endforeach;
                    }

                    //echo "\n---------------------------- Fin de Lista Ingredientes -----------------------\n";
                endforeach;

                //echo "\n---------------------------- Fin de Objeto -----------------------\n";
            endforeach;

            /*
            *
            * Insertar bebidas
            * de la pizza
            *
            */
            if (!empty($listaBebs)) {
                foreach ($listaBebs as $bebida) {
                    if (!$this->con->query("INSERT into lista_bebida (refPedido, refBebida) values ('$lastIdPedido', '$bebida->id')")) {
                        global $errores;
                        $errores = array(
                            "numError" => $this->con->errno,
                            //"numError" => $total,
                            "descError" => $this->con->error);
                        return false;
                    }
                }
            }

            /*
            *
            * Insertar lasanias
            * de la pizza
            *
            */

            if (!empty($listaLasania)) {
                foreach ($listaLasania as $lasania) {
                    if (!$this->con->query("INSERT into lista_lasania (refPedido, refLasania) values ('$lastIdPedido', '$lasania->id')")) {
                        global $errores;
                        $errores = array(
                            "numError" => $this->con->errno,
                            //"numError" => $total,
                            "descError" => $this->con->error);
                        return false;
                    }
                }
            }

            /*
            *
            * Insertar pasta
            * de la pizza
            *
            */

            if (!empty($listaPasta)) {
                foreach ($listaPasta as $pasta) {
                    if (!$this->con->query("INSERT into lista_pasta (refPedido, refPasta) values ('$lastIdPedido', '$pasta->id')")) {
                        global $errores;
                        $errores = array(
                            "numError" => $this->con->errno,
                            //"numError" => $total,
                            "descError" => $this->con->error);
                        return false;
                    }
                }
            }

            /*
            *
            * Insertar ensaladas
            * de la pizza
            *
            */

            if (!empty($listaEnsaladas)) {
                foreach ($listaEnsaladas as $ensalada) {
                    if (!$this->con->query("INSERT into lista_ensal (refPedido, refEnsal) values ('$lastIdPedido', '$ensalada->id')")) {
                        global $errores;
                        $errores = array(
                            "numError" => $this->con->errno,
                            //"numError" => $total,
                            "descError" => $this->con->error);
                        return false;
                    }
                }
            }

            /*
            *
            * Insertar hamburguesas
            * de la pizza
            *
            */

            if (!empty($listaHamburguesas)) {
                foreach ($listaHamburguesas as $hamburguesa) {
                    if (!$this->con->query("INSERT into lista_hamb (refPedido, refHamb) values ('$lastIdPedido', '$hamburguesa->id')")) {
                        global $errores;
                        $errores = array(
                            "numError" => $this->con->errno,
                            //"numError" => $total,
                            "descError" => $this->con->error);
                        return false;
                    }
                }
            }

            return true;
        } catch (Exception $e) {
            global $errores;
            $errores = array(
                //"numError" => $stmt->errno,
                "numError" => $refCliente,
                "descError" => $this->con->error);
            echo $e->errorMessage();
        }
    }


    /*
    * Select pedidos por parametro
    */
    function getPedido($nombreParametro, $valorParametro)
    {
        $stmt = $this->con->prepare("SELECT * FROM pedido where $nombreParametro = ?");
        if ($stmt) {
            $stmt->bind_param("i", $valorParametro);
            $stmt->execute();
            $stmt->bind_result($id, $refCliente, $numPedido, $fechaPedido, $extra_domicilio, $extra_local, $extra_recoger, $subtotal, $impuesto, $total);

            $pedidos = array();

            while ($stmt->fetch()) {
                $pedido = array();
                $pedido['id'] = $id;
                $pedido['refCliente'] = $refCliente;
                $pedido['numPedido'] = $numPedido;
                $pedido['fechaPedido'] = $fechaPedido;
                $pedido['extra_domicilio'] = $extra_domicilio;
                $pedido['extra_local'] = $extra_local;
                $pedido['extra_recoger'] = $extra_recoger;
                $pedido['subtotal'] = $subtotal;
                $pedido['impuesto'] = $impuesto;
                $pedido['total'] = $total;

                array_push($pedidos, $pedido);
            }
        }
        return $pedidos;
    }


    /*
    * The delete operation
    * When this method is called record is deleted for the given id
    */
    function deleteHero($id)
    {
        $stmt = $this->con->prepare("DELETE FROM heroes WHERE id = ? ");
        $stmt->bind_param("i", $id);
        if ($stmt->execute())
            return true;

        return false;
    }
}

?>
